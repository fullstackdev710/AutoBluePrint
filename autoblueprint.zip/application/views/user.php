<h1>
   User
</h1>
<a href="<?php echo site_url('login/logout'); ?>">logout</a>