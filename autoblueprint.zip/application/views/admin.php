<h1>
   Admin
</h1>
<a href="<?php echo site_url('login/logout'); ?>">logout</a>