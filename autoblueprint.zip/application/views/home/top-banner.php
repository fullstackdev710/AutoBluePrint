<?php defined("BASEPATH") or exit(); ?>

<section id="top_banner">
   <div class="container">
      <div class="row">
         <div class="col">
            <h1 class="text-center text-white">
               Discover The<br>
               <span class="text-red">Secret Formula</span><br>
               That Has Our Members Prospering Within<br>
               <span class="text-red text-decoration-underline">Days Of Joining</span>!
            </h1>
         </div>
      </div>
   </div>
</section>