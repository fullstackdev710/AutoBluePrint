<?php defined("BASEPATH") or exit(); ?>

<section id="contact_title">
   <div class="container">
      <div class="row">
         <div class="col">
            <h1 class="text-center text-white">
               <span class="text-red text-decoration-underline">Call The Success Coach Hotline</span><br>
               <span class="text-red">(</span>929<span class="text-red">)</span> 459<span class="text-red">-</span>2777
            </h1>
            <h1 class="text-center text-red" style="font-family: 'Muli',Helvetica,Arial,Lucida,sans-serif; font-size: 35px; text-shadow: 1px 2px 0em #000;">
               24 hours / 7 Days
            </h1>
         </div>
      </div>
   </div>
</section>